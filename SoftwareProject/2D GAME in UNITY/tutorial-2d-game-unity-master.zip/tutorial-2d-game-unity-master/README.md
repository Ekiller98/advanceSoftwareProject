Make a 2D game with Unity 5
=============================

This is the repository related to our tutorial [Creating a 2D game with Unity](http://pixelnest.io/tutorials/2d-game-unity/).

It contains the final source code, assets and license information of our little demo project, a shoot them up based on [The Great Paper Adventure](http://dmayance.com/the-great-paper-adventure-of/).

